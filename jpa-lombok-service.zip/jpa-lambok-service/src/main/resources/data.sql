
insert into BOOK(isbn,title,price,stock,category) values('1234','C',150.25,100,'technical')
insert into BOOK(isbn,title,price,stock,category) values('3467','CPlus',170.25,100,'technical')
