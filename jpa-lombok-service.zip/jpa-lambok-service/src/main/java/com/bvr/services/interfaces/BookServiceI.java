package com.bvr.services.interfaces;

import java.util.List;

import com.bvr.bean.Book;

public interface BookServiceI {
	
	public Book addbook(Book book);
	public List<Book> getAllBooks();
	public Book getBook(String isbn);
	public Book deleteBook(String isbn);
	public Book upateBook(String isbn,long newStock);
	
}