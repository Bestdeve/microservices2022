package com.ibm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
@Controller
public class Secured3Application {

	public static void main(String[] args) {
		SpringApplication.run(Secured3Application.class, args);
	}
	
	
	@GetMapping("/")
	public String index(final Model model)
	{
		model.addAttribute("title", "Welcome to SSL Demo ");
		model.addAttribute("msg", "SSL Enabled Component");
		return "index";
	}

}
